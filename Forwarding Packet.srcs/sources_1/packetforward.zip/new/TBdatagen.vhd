library IEEE;
use IEEE.STD_LOGIC_1164.all;
use IEEE.STD_LOGIC_ARITH.all;
use IEEE.STD_LOGIC_UNSIGNED.all;

Entity TBdatagen Is
End Entity TBdatagen;

Architecture behavioral Of TBdatagen Is

--------------------------------------------------------------------------------------------
-- Constant Declaration
--------------------------------------------------------------------------------------------

	constant	tClk			: time := 10 ns;
	
-------------------------------------------------------------------------
-- Component Declaration
-------------------------------------------------------------------------
	
	Component datagen is
    Port ( 	clk 		: in  STD_LOGIC;
			rst 		: in  STD_LOGIC;
			sw_start 	: in  STD_LOGIC;
			o_data 		: out  STD_LOGIC);
	end Component datagen;
	
-------------------------------------------------------------------------
-- Signal Declaration
-------------------------------------------------------------------------
	
	signal	clk			: std_logic   := '0';
	signal	rst			: std_logic   := '0';
	signal	sw_start	: std_logic   := '1';
	
	signal	o_data		: std_logic   ;
	
	signal	eth_data	: std_logic_vector( 575 downto 0 );
	
Begin

----------------------------------------------------------------------------------
-- Concurrent signal
----------------------------------------------------------------------------------
	
	uut : datagen
	port map
	(
		clk			=>	clk			,
		rst			=>	rst			,
		sw_start	=>	sw_start	,
		o_data		=>	o_data
	);
	
	u_rst : Process
	Begin
		rst	<= '0';
		wait for 20*tClk;
		rst	<= '1';
		wait;
	End Process;

	u_clk : Process
	Begin
		clk		<= '1';
		wait for tClk/2;
		clk		<= '0';
		wait for tClk/2;
	End Process;
	
-------------------------------------------------------------------------
-- Testbench
-------------------------------------------------------------------------

	stim_proc: process
	Begin
	    eth_data <=(OTHERS=>'1');
		wait for 30*tClk;
		sw_start <= '0';
		wait for tClk;
		eth_data(575 downto 0)     <= o_data & eth_data (575 downto 1);
		wait for tClk;
		sw_start <= '1';
		eth_data(575 downto 0)     <= o_data & eth_data (575 downto 1);
		for i in 0 to 578 loop
		  wait for tClk;
		  eth_data(575 downto 0)     <= o_data & eth_data (575 downto 1);
		end loop;
		wait for 30*tClk;
		wait;
	End Process;

End Architecture behavioral;