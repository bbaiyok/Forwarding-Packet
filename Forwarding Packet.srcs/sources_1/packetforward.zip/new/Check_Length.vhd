----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 03/09/2025 01:54:43 AM
-- Design Name: 
-- Module Name: Check_Length - Behavioral
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------


library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity Check_Length is
    Port ( clk 				: in STD_LOGIC;
		   rst				: in STD_LOGIC;
		   i_EnRdLength	 	: in STD_LOGIC;
           i_lengthbytes 	: in STD_LOGIC_VECTOR (15 downto 0);
           RdEnEthFrLength 	: out STD_LOGIC);
end Check_Length;

architecture Behavioral of Check_Length is
	
	signal	EthFrBytCnt     : integer range 0 to 12500;
	signal	SndEthFrCnt     : integer range 0 to 12500;
	signal	PayloadBytCnt   : integer range 0 to 65535;
	signal  RdEn            : std_logic;
	signal  r_EnRdLeng      : std_logic_vector (1 downto 0);
	
begin
	
	PayloadBytCnt 	<= to_integer(unsigned(i_lengthbytes));
	RdEnEthFrLength	<= RdEn;
	
	-- delay received length
	u_delay : process (clk) is
	begin
		if rising_edge(clk) then
		    r_EnRdLeng <= r_EnRdLeng(0) & i_EnRdLength;
		end if;
	end process u_delay;
	
	-- collect length data
	u_collect : process (clk) is
	begin
		if rising_edge(clk) then
			if rst = '0' then
				EthFrBytCnt <= 0;
			elsif i_EnRdLength = '1' then
				EthFrBytCnt <= ((26 + PayloadBytCnt)*8) - 1;
			else
				EthFrBytCnt <= 0;
			end if;
		end if;
	end process u_collect;
	
	-- set counter for send enable signal to demux
	u_CntEthFr : process (clk) is
	begin
		if rising_edge(clk) then
			if r_EnRdLeng(0) = '1' then
			    SndEthFrCnt <= EthFrBytCnt;
			else
			    if SndEthFrCnt /= 0 then
			        SndEthFrCnt <= SndEthFrCnt - 1;
			    else
				    SndEthFrCnt <= 0;
				end if;
			end if;
		end if;
	end process u_CntEthFr;
	
	-- check counter for send enable signal to demux
	u_EnSendEthFr : process (clk) is
	begin
		if rising_edge(clk) then
			if SndEthFrCnt /= 0 then
			    RdEn <= '1';
			else
				RdEn <= '0';
			end if;
		end if;
	end process u_EnSendEthFr;
	
end Behavioral;
